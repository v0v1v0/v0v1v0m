########################################################
# Block 2: Executing a Number
########################################################

# R-bot: Predict what happens when you type 42 in the console.
42


########################################################
# Block 3: Assigning a Value to a Variable
########################################################

# R-bot: Predict what happens when you assign 42 to x.
x <- ___
# Reflect: Check if x appears in your environment.


########################################################
# Block 4: Incomplete Statements
########################################################

# R-bot: Predict the error message when you type an incomplete statement.
# Example: y <-
y <-


########################################################
# Block 5: Completing an Assignment
########################################################

# R-bot: Complete the assignment by assigning 100 to y.
y <- ___
# Reflect: What happens when the statement is completed?


########################################################
# Block 6: Complete Function Calls
########################################################

# R-bot: Predict what happens when you type print(x).
print(x)


########################################################
# Block 7: Incomplete Function Calls
########################################################

# R-bot: Predict the error when you type print( without closing the parenthesis.
print(


########################################################
# Block 8: Reflecting on Complete Statements
########################################################

# R-bot: Reflect: Why does R require complete statements to execute code?
# Write down your thoughts or discuss them with a peer.


########################################################
# Block 9: Quiz on Complete Statements
########################################################

# R-bot: Which of the following is a complete statement in R?
quiz_answer <- ___
# Options:
# 1: x <- 5
# 2: print(
# 3: y <-

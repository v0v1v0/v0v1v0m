########################################################
# Block 2: Creating Variables
########################################################

# R-bot: Create variables a and b.
a <- ___
b <- ___
# Reflect: How does using variables help simplify calculations?


########################################################
# Block 3: Combining Variables
########################################################

# R-bot: Add a and b, assigning the result to total.
total <- ___ + ___
# Reflect: What does this demonstrate about the usefulness of variables?


########################################################
# Block 4: Listing Variables
########################################################

# R-bot: Use ls() to list all active variables in your environment.
ls()


########################################################
# Block 5: Naming Variables
########################################################

# R-bot: Why might descriptive names like total_sales be better than ts?
# Write your thoughts below:


########################################################
# Block 6: Removing Variables
########################################################

# R-bot: Remove the variable total.
rm(___)


########################################################
# Block 7: Clearing the Environment
########################################################

# R-bot: Clear all variables from your environment.
rm(list = ___)


########################################################
# Block 8: Saving Scripts
########################################################

# R-bot: Why is it important to save scripts with descriptive names?
# Name your script my-first-script and write your thoughts below:


########################################################
# Block 9: Quiz on Managing Variables
########################################################

# R-bot: Which of the following is a good practice for managing variables?
quiz_answer <- ___
# Options:
# 1: Use short, unclear names like ts.
# 2: Keep unused variables to avoid losing data.
# 3: Remove unused variables to keep the workspace clean.
# 4: Avoid using ls() to track variables.

########################################################
# Block 2: Why Use Scripts?
########################################################

# R-bot: Predict why it’s useful to store multiple lines of code in a script.
# Example code:
# x <- 10
# y <- 20
# print(x + y)


########################################################
# Block 3: Running a Script
########################################################

# R-bot: Write the following lines in the script editor:
x <- ___
y <- ___
print(x + y)


########################################################
# Block 4: Highlight and Run Specific Code
########################################################

# R-bot: Highlight the line below and run it.
x <- ___
# Reflect: What happens when only this line is executed?


########################################################
# Block 5: Control + Enter for Highlighted Code
########################################################

# R-bot: Highlight the line below and press Control + Enter.
y <- ___
# Reflect: How does this shortcut improve efficiency?


########################################################
# Block 6: Running One Line Without Highlighting
########################################################

# R-bot: Place the cursor here and press Control + Enter.
print(x + y)


########################################################
# Block 7: Reflection on Scripts
########################################################

# R-bot: Reflect: How do scripts improve debugging and testing workflows?
# Write your thoughts below:


########################################################
# Block 8: Sharing and Organizing Scripts
########################################################

# R-bot: Why is it important to save and name your scripts clearly?
# Write your thoughts below:


########################################################
# Block 9: Quiz on Script Best Practices
########################################################

# R-bot: Which of these is a good practice when using scripts?
quiz_answer <- ___
# Options:
# 1: Always type code directly in the console.
# 2: Use scripts to save and organize code for reuse.
# 3: Avoid naming scripts clearly to save time.
# 4: Use the play button for single lines of code.

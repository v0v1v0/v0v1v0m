########################################################
# Block 2: Selecting a Specific Position
########################################################

# R-bot: Predict the result of vec[2] when vec <- 5:10.
vec <- 5:10
second_element <- ___
# Reflect: How would you select the last element?


########################################################
# Block 3: Selecting Multiple Positions
########################################################

# R-bot: Predict the result of vec[c(1, 3, 5)].
selected_positions <- c(___, ___, ___)
# Explore: What happens if you use repeated indexes, like vec[c(1, 1, 3)]?


########################################################
# Block 4: Excluding Elements
########################################################

# R-bot: Predict the result of vec[-(1:3)].
excluded_positions <- c(___, ___)
# Reflect: How would you exclude only the first and last elements?


########################################################
# Block 5: Filtering with a Condition
########################################################

# R-bot: Predict the result of vec[vec > 6].
greater_than_six <- ___
# Reflect: How would you filter for elements <= 6?


########################################################
# Block 6: Finding Positions with which()
########################################################

# R-bot: Predict the result of which(vec > 6).
positions_gt_six <- ___
# Explore: What happens if the condition doesn’t match any elements?


########################################################
# Block 7: Set Operations
########################################################

# R-bot: Predict the result of setdiff(5:10, 7:8).
difference <- ___
# Reflect: What happens if the second vector is empty?


########################################################
# Block 8: Quiz on Excluding Elements
########################################################

# R-bot: Which operation excludes specific elements from a vector?
quiz_answer <- ___
# Select from 1: vec[-2], 2: vec[c(2, 3)], or 3: vec[vec > 6].

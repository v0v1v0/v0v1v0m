########################################################
# Block 1: Getting Started
########################################################
# R-bot: Welcome! You’ve opened the R script as instructed.
# Let’s proceed to the first concept.


########################################################
# Block 2: Creating and Viewing a Numeric Vector
########################################################
# R-bot: Create x <- c(1, 2, 3, 4, 5).
x <- 


########################################################
# Block 3: Mixing Data Types in a Vector
########################################################
# R-bot: What if you mix numbers and characters?
# Predict the resulting type. Write the types you expect.
x <- c(__, __, __)
# Reflect: Why did R convert the values that way?


########################################################
# Block 4: Logical, Integer, Numeric Mix
########################################################
# R-bot: Predict what happens if you combine TRUE, 1L, and 3.14.
# Write the values as they would be coerced.
x <- c(__, __, __)
# Reflect: Why did R convert the values that way?


########################################################
# Block 5: Introduction to Factors
########################################################
# R-bot: Factors store categories.
# Consider colors <- factor(c("red", "blue", "red", "green")).
# Which unique categories become levels?
colors <- factor(c("red", "blue", "red", "green"))
levels(___)

########################################################
# Block 6: Ordered Factors
########################################################
# R-bot: For ordered factors, define a ranking.
# priority <- factor(c("high","medium","low","medium"),
#                    levels=c("low","medium","high"),
#                    ordered=TRUE)
# Predict the order before checking.
priority <- factor(c("high","medium","low","medium"),
                   levels=c("low","medium","high"),
                   ordered=TRUE)
levels(___)

########################################################
# Block 7: Inspecting Factors
########################################################
# R-bot: Use typeof(priority) and class(priority).
# Predict: typeof() -> integer, class() -> ordered factor.
typeof(priority)
class(___)


########################################################
# Block 8: Character Vectors
########################################################
# R-bot: Create a character vector of names.
# names <- c("Alice","Bob","Charlie")
names <- c("Alice", __, __)
# Reflect on how this differs from factors.

########################################################
# Block 9: Quiz on Numeric Vectors
########################################################
# R-bot: Which option creates a pure vector of doubles?
# 1. c(1,2,3,"4")
# 2. c(1,2.0,3,4)
# 3. c(TRUE,FALSE,3L)
quiz_answer <- __

########################################################
# Block 2: Equality Comparison
########################################################
# R-bot: Predict the result of 1:3 == c(1, 3, 2).
result_equal <- c(___, ___, ___)
# Reflect: What would the result be if you used c(1, 99, 3)?


########################################################
# Block 3: Inequality Comparison
########################################################
# R-bot: Predict the result of 1:3 != c(1, 3, 2).
result_not_equal <- c(___, ___, ___)
# Compare this result with the equality comparison in Block 1.


########################################################
# Block 4: Greater-Than Conditions
########################################################
# R-bot: Predict the result of 1:4 > 2.
greater_than_two <- c(___, ___, ___, ___)
# Reflect: What happens if you try 1:4 >= 2?


########################################################
# Block 5: Missing Values
########################################################
# R-bot: Predict the result of is.na(c(1, NA, 3)).
missing_values <- c(___, ___, ___)



########################################################
# Block 6: Null Values
########################################################
# R-bot: Predict the result of is.null(NULL).
null_check <- ___



########################################################
# Block 7: Checking All Elements
########################################################
# R-bot: Predict the result of all(c(TRUE, TRUE)).
all_true <- ___
# Reflect: Why would all(c(TRUE, FALSE)) return FALSE?


########################################################
# Block 8: Finding Positions with match()
########################################################
# R-bot: Predict the result of match(2, c(1, 2, 3)).
match_result <- ___
# What happens if the value is not found in the vector?


########################################################
# Block 9: Finding Positions with which()
########################################################
# R-bot: Predict the result of which(c(FALSE, TRUE, TRUE)).
true_positions <- c(___, ___)
# Reflect: How is which() different from match()?


########################################################
# Block 10: Quiz on Vector Functions
########################################################
# R-bot: Which function checks if all elements in a vector are TRUE?
quiz_answer <- ___
# Select from:
# 1: is.na()
# 2: all() 
# 3: match()

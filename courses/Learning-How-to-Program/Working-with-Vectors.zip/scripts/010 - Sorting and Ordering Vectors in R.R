########################################################
# Block 2: Sorting in Ascending Order
########################################################

# R-bot: Predict the result of sort(x) when x <- c(1, 3, 2).
x <- c(1, 3, 2)
sorted_x <- c(___, ___, ___)
# Reflect: How would you check if the vector is already sorted?



########################################################
# Block 3: Sorting in Descending Order
########################################################

# R-bot: Predict the result of sort(x, decreasing = TRUE).
desc_sorted_x <- c(___, ___, ___)
# Explore: What happens if x contains repeated elements?


########################################################
# Block 4: Sorting with Missing Values
########################################################

# R-bot: Predict the result of sort(c(1, 3, NA, 2), na.last = TRUE).
sorted_with_na <- c(___, ___, ___, ___)
# Reflect: How would the result change if na.last = FALSE?


########################################################
# Block 5: Sorting with Missing Values at the Start
########################################################

# R-bot: Predict the result of sort(c(1, 3, NA, 2), na.last = FALSE).
sorted_na_first <- c(___, ___, ___, ___)


########################################################
# Block 6: Using order() to Find Indices
########################################################

# R-bot: Predict the result of order(c(2, 1, 3, 2)).
order_indices <- c(___, ___, ___, ___)
# Reflect: How is order() different from sort()?


########################################################
# Block 7: Using order() to Reorder a Vector
########################################################

# R-bot: Predict the result of c(2, 1, 3, 2)[order(c(2, 1, 3, 2))].
ordered_vec <- c(___, ___, ___, ___)
# Explore: How would the result change if decreasing = TRUE was added?


########################################################
# Block 8: Quiz on sort() and order()
########################################################

# R-bot: Which of the following statements is true about sort() and order()?
# 1. sort() returns a vector sorted by values, while order() returns the indices of the sorted order.
# 2. sort() and order() both return sorted values.
# 3. sort() is slower than order() for large vectors.
quiz_answer <- __
# Fill in the correct number based on your understanding.

########################################################
# Block 1
########################################################
# R-bot: Welcome! You've opened the R script, let's begin.


########################################################
# Block 2: Colon Operator
########################################################
# R-bot: Which command directly uses `:` to create integers from 1 to 10?
# 1. 1:10
# 2. seq(1,10)
# 3. c(1, 2, 3, 4, 5, 6, 7, 8, 9 ,10)
#
# Assign the correct number to colon_answer.
colon_answer <- __


########################################################
# Block 3: Using seq() with a Step Size
########################################################
# R-bot: Create c(2,4,6,8,10) using seq().
# Start at 2, end at 10, steps of 2.
even_seq <- seq(__, __, by = __)


########################################################
# Block 4: Reverse-Engineering a seq() Call
########################################################
# R-bot: You need c(1,4,7,10).
# Start=?, end=?, step=?.
my_arithmetic_seq <- seq(__, __, by = __)


########################################################
# Block 5: Interpretation Task
########################################################
# R-bot: seq(2,10,by=3) creates a sequence by adding 3 each time starting at 2.
correct_seq_vector <- c(__, __, __)


########################################################
# Block 6: Using rep(times)
########################################################
# R-bot: Repeat c(1,2,3) three times to get c(1,2,3,1,2,3,1,2,3).
daily_cycle <- rep(__:__, times = __)


########################################################
# Block 7: Using rep(each)
########################################################
# R-bot: Turn c(1,2,3) into c(1,1,2,2,3,3) by repeating each element twice.
doubled_elements <- rep(__:__, each = __)


########################################################
# Block 8: Predict & Verify rev()
########################################################
# R-bot: Produce c(5,4,3,2,1).
reversed_seq <- ___

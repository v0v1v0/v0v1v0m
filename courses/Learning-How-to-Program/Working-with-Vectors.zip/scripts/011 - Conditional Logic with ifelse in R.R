########################################################
# Block 2: Basic ifelse Logic
########################################################

# R-bot: Predict the result of ifelse(c(TRUE, FALSE, FALSE), 'yes', 'no').
logic_result <- c(___, ___, ___)



########################################################
# Block 3: Labeling Numeric Vectors
########################################################

# R-bot: Predict the result of labeling numbers greater than 3 as 'high' and others as 'low'.
numeric_labels <- c(_____, _____, _____, _____, _____, _____)
# Explore: What happens if the range is 2:6?


########################################################
# Block 4: Nested ifelse for Multiple Categories
########################################################

# R-bot: Predict the result of this nested ifelse statement.
nested_labels <- c(_____, _____, _____, _____, _____, _____)
# Reflect: Can you write this logic without nesting?


########################################################
# Block 5: Practice - Categorizing Scores
########################################################

# R-bot: Create a numeric vector scores <- 1:6.
scores <- 1:6
# Use nested ifelse to categorize:
# > 5 as 'excellent', >= 3 as 'good', < 3 as 'needs improvement'.
score_labels <- c(_____, _____, _____, _____, _____, _____)


########################################################
# Block 6: Quiz on ifelse
########################################################

# R-bot: Which of the following statements about ifelse is correct?
quiz_answer <- ___
# Select from:
# 1: ifelse only works with numeric vectors.
# 2: ifelse applies conditions to each element independently.
# 3: ifelse requires nested statements for simple cases.

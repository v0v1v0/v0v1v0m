########################################################
# Block 1: Getting Started
########################################################

# R-bot: Welcome! Open this script to begin working through the lesson.


########################################################
# Block 2: Vector Addition
########################################################

# R-bot: Predict the result of c(1,2,3) + c(4,5,6).
# Do the calculation in your head.
result_add <- c(___, ___, ___) 



########################################################
# Block 3: Vector Subtraction
########################################################

# R-bot: Predict the result of c(1,2,3) - c(4,5,6).
# Do the calculation in your head.
result_sub <- c(___, ___, ___)



########################################################
# Block 4: Vector Multiplication
########################################################

# R-bot: Predict the result of c(1,2,3) * c(4,5,6).
# Do the calculation in your head.
result_mult <- c(___, ___, ___)



########################################################
# Block 5: Operator Precedence
########################################################

# R-bot: Compute 2+3*4 and (2+3)*4 manually.
# Do the calculation in your head.
result1 <- ___  # 2 + 3*4
result2 <- ___  # (2 + 3)*4


########################################################
# Block 6: Vector Length
########################################################

# R-bot: What is the length of c(1,2,3,4,5)?
# Do it without using the length function.
vector_length <- ___ 


########################################################
# Block 7: Vector Recycling (Simple)
########################################################

# R-bot: Predict the result of c(1,2,3) + 1.
recycled_vector <- c(___, ___, ___)
# Why do they call it recycling?

########################################################
# Block 8: Recycling with a Warning
########################################################

# R-bot: Predict the result of c(1,2,3) + c(10,20).
uneven_recycle <- c(___, ___, ___)


########################################################
# Block 9: Quiz on Vector Arithmetic
########################################################

# R-bot: Which option demonstrates correct vector arithmetic?
quiz_answer <- ___
# 1. c(1, 2, '3') + c(4, 5)
# 2. c(1, 2, 3) * c(4, 5, 6)
# 3. c(1, 2, 3) / c(4, '5', 6)
########################################################
# Block 2: Single Square Brackets
########################################################

# R-bot: Create a list with three named elements.
my_list <- list(a = 5, b = 10, c = 15)
# Use single square brackets to select the first element, preserving its structure as a list.
first_item_list <- __


########################################################
# Block 3: Double Square Brackets
########################################################

# R-bot: Access the value inside the first element using double square brackets.
first_item_value <- __


########################################################
# Block 4: Selecting Multiple Elements by Name
########################################################

# R-bot: Create a sublist containing elements 'a' and 'c'.
my_sublist <- __


########################################################
# Block 5: Updating Elements in a List
########################################################

# R-bot: Change the third element to "changed c".
my_list[[__]] <- ___


########################################################
# Block 6: Adding New Elements to a List
########################################################

# R-bot: Add a fourth element with the value 4.
my_list[[__]] <- ___


########################################################
# Block 7: Removing Elements from a List
########################################################

# R-bot: Remove the fourth element by setting it to NULL.
my_list[[__]] <- NULL


########################################################
# Block 8: Accessing Named Elements with $
########################################################

# R-bot: Access the first element of the list using the $ operator.
first_named_element <- my_list$__


########################################################
# Block 9: Quiz on List Behaviors
########################################################

# R-bot: Which of the following statements about lists is TRUE?
quiz_answer <- ___
# Options:
# 1. Single square brackets always return a list.
# 2. Double square brackets extract the value directly from the list.
# 3. Lists can store elements of different types.
# 4. All of the above.

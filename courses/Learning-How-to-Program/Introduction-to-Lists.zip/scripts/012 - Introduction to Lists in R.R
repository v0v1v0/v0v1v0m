########################################################
# Block 2: Creating a List
########################################################

# R-bot: Create a list containing 1 and "1".
my_list <- list(___, ___)
# Reflect: Why is it useful to store elements of different types in a single structure?


########################################################
# Block 3: Using c() vs list()
########################################################

# R-bot: Store the same elements using c() and observe the difference.
my_vector <- c(___, ___)
# Reflect: How does c() handle mixed types compared to list()?


########################################################
# Block 4: Naming List Elements
########################################################

# R-bot: Create a named list.
my_named_list <- list(x1 = ___, x2 = ___)
# Reflect: Why do names make lists more readable and easier to manipulate?


########################################################
# Block 5: Naming Elements After Creation
########################################################

# R-bot: Assign names to my_list after creation.
names(my_list) <- c(___, ___)
# Reflect: How does naming elements after creation compare to naming them during creation?


########################################################
# Block 6: Creating an Empty List
########################################################

# R-bot: Pre-allocate an empty list with 3 slots.
my_empty_list <- vector("list", ___)
# Reflect: Why might pre-allocating an empty list be useful?


########################################################
# Block 7: Updating Named List Elements
########################################################

# R-bot: Update the first two elements of my_named_list.
my_named_list[1:2] <- list(___, ___)
# Reflect: How does this flexibility make lists useful for dynamic data?


########################################################
# Block 8: Quiz on Lists
########################################################

# R-bot: Which of the following statements about lists is TRUE?
quiz_answer <- ___
# Options:
# 1. Lists in R require all elements to be of the same type.
# 2. Lists in R allow mixing data types and can preserve element types.
# 3. You cannot update elements in a list after it is created.

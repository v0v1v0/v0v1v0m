########################################################
# Block 2: Converting Lists to Atomic Vectors
########################################################

# R-bot: Create a list with four numeric elements.
my_list <- list(1, 2, 3, 4)
# Convert the list to an atomic vector.
my_vector <- ___


########################################################
# Block 3: Inspecting Structure
########################################################

# R-bot: Check the class of my_list and my_vector.
list_class <- class(___)
vector_class <- class(___)


########################################################
# Block 4: Accessing Elements by Position
########################################################

# R-bot: Retrieve the 4th element from my_vector.
fourth_element <- __


########################################################
# Block 5: Naming and Accessing Elements
########################################################

# R-bot: Assign names to the vector elements.
names(my_vector) <- c('x1', 'x2', 'x3', 'x4')
# Retrieve the element named 'x4'.
named_element <- __


########################################################
# Block 6: Comparing Position and Name Access
########################################################

# R-bot: Retrieve the 4th element by position and by name.
position_access <- my_vector[__]
name_access <- my_vector[__]


########################################################
# Block 7: Quiz on Converting Lists to Vectors
########################################################

# R-bot: Which statement about converting lists to atomic vectors is TRUE?
quiz_answer <- ___
# Options:
# 1. Lists can be directly used in numeric operations without conversion.
# 2. The unlist() function simplifies a list into an atomic vector.
# 3. Atomic vectors allow mixed data types like lists.
# 4. Naming vector elements is only possible with lists.
